package com.example.mobileprogrammingassignment

import java.io.*

class FileManager ()
{

    val file = File("user.txt")
    var fw: FileWriter? = null
    var bufwr: BufferedWriter? = null
    var fr: FileReader? = null
    var bufrd: BufferedReader? = null

    var data: String = ""
    var temp: String = ""

    private fun openFile()
    {
        try
        {
            fw = FileWriter(file)
            bufwr = BufferedWriter(fw)

            fr = FileReader(file)
            bufrd = BufferedReader(fr)

        }
        catch (e: Exception)
        {
            e.printStackTrace()
        }
    }

    private fun closeFile()
    {
        try
        {
            if (bufwr != null)
                bufwr!!.close()

            if (fw != null)
                fw!!.close()

            if (bufrd != null)
                bufrd!!.close()

            if (fr != null)
                fr!!.close()
        }
        catch (e: Exception)
        {
            e.printStackTrace()
        }
    }

    fun readFile(): String
    {
        openFile()
        data = ""
        try
        {
            while(true)
            {
                temp = bufrd!!.readLine()
                data += "\n"+temp
            }
        }
        catch (e: java.lang.Exception)
        {
            e.printStackTrace()
        }
        closeFile()
        return data
    }

    fun writeFile(str: String)
    {
        openFile()
        data += "\n"+str
        bufwr!!.write(data)
        closeFile()
    }
}