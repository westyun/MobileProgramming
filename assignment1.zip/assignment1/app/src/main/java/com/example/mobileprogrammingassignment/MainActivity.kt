package com.example.mobileprogrammingassignment

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.text.isDigitsOnly
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity()
{

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val title = text_title
        val input = editText_input_money
        val result = editText_result
        val d2w = btn_d2w
        val w2d = btn_w2d

        d2w.setOnClickListener {
            if (input.length() > 0 && input.text.isDigitsOnly())
            {
                result.setText((input.text.toString().toInt()*1200).toString())
            }
        }

        w2d.setOnClickListener {
            if (input.length() > 0 && input.text.isDigitsOnly())
            {
                result.setText((input.text.toString().toFloat()/1200).toString())
            }
        }
    }
}
